.. pyLoad documentation master file, created by
   sphinx-quickstart on Sat Jun  4 11:54:34 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyLoad's documentation!
==================================

Great that you found your way to the pyLoad documentation!

We have collected some information here to help developer writing plugins and understandig our code.
If you want to help us developing visit us in our IRC channel #pyload on freenode.net or leave a message in our forum.

Contents:

.. toctree::
   :maxdepth: 2

   access_api.rst
   extend_pyload.rst
   module_overview.rst

.. currentmodule:: module

==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
