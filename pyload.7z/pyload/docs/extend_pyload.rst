.. _extend_pyload:

********************
How to extend pyLoad                                                                                                                
********************

In general there a two different plugin types. These allow everybody to write powerful, modular plugins without knowing
every detail of the pyLoad core. However you should have some basic knowledge of python.

.. toctree::

    write_hooks.rst
    write_plugins.rst