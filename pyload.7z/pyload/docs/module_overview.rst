Module Overview
===============

You can find an overview of some important classes here:

.. autosummary::
   :toctree: module

   module.Api.Api
   module.plugins.Plugin.Base
   module.plugins.Plugin.Plugin
   module.plugins.Crypter.Crypter
   module.plugins.Account.Account
   module.plugins.Hook.Hook
   module.HookManager.HookManager
   module.PyFile.PyFile
   module.PyPackage.PyPackage
